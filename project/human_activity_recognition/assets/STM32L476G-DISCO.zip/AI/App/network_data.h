/**
  ******************************************************************************
  * @file    network_data.h
  * @author  AST Embedded Analytics Research Platform
  * @date    2026-10-12T11:02:50+0800
  * @brief   AI Tool Automatic Code Generator for Embedded NN computing
  ******************************************************************************
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  ******************************************************************************
  */

#ifndef STAI_NETWORK_DATA_H
#define STAI_NETWORK_DATA_H
#include "stai.h"
STAI_ALIGNED(8)
extern const uint64_t g_network_weights_array[1532];
#endif  /* STAI_NETWORK_DATA_H */

